import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

import components.map.Map;

/**
 * JUnit test fixture for {@code Map<String, String>}'s constructor and kernel
 * methods.
 *
 * @author ZiyiWang, HuiyanNi
 *
 */
public abstract class MapTest {

    /**
     * Invokes the appropriate {@code Map} constructor for the implementation
     * under test and returns the result.
     *
     * @return the new map
     * @ensures constructorTest = {}
     */
    protected abstract Map<String, String> constructorTest();

    /**
     * Invokes the appropriate {@code Map} constructor for the reference
     * implementation and returns the result.
     *
     * @return the new map
     * @ensures constructorRef = {}
     */
    protected abstract Map<String, String> constructorRef();

    /**
     *
     * Creates and returns a {@code Map<String, String>} of the implementation
     * under test type with the given entries.
     *
     * @param args
     *            the (key, value) pairs for the map
     * @return the constructed map
     * @requires <pre>
     * [args.length is even]  and
     * [the 'key' entries in args are unique]
     * </pre>
     * @ensures createFromArgsTest = [pairs in args]
     */
    private Map<String, String> createFromArgsTest(String... args) {
        assert args.length % 2 == 0 : "Violation of: args.length is even";
        Map<String, String> map = this.constructorTest();
        for (int i = 0; i < args.length; i += 2) {
            assert !map.hasKey(args[i]) : ""
                    + "Violation of: the 'key' entries in args are unique";
            map.add(args[i], args[i + 1]);
        }
        return map;
    }

    /**
     *
     * Creates and returns a {@code Map<String, String>} of the reference
     * implementation type with the given entries.
     *
     * @param args
     *            the (key, value) pairs for the map
     * @return the constructed map
     * @requires <pre>
     * [args.length is even]  and
     * [the 'key' entries in args are unique]
     * </pre>
     * @ensures createFromArgsRef = [pairs in args]
     */
    private Map<String, String> createFromArgsRef(String... args) {
        assert args.length % 2 == 0 : "Violation of: args.length is even";
        Map<String, String> map = this.constructorRef();
        for (int i = 0; i < args.length; i += 2) {
            assert !map.hasKey(args[i]) : ""
                    + "Violation of: the 'key' entries in args are unique";
            map.add(args[i], args[i + 1]);
        }
        return map;
    }

    // TODO - add test cases for constructor, add, remove, removeAny, value,
    // hasKey, and size
    @Test
    public final void testMapConstructor() {
        Map<String, String> test = this.constructorTest();
        Map<String, String> expected = this.constructorRef();

        assertEquals(expected, test);
    }

    @Test
    public final void testAdd01() {
        Map<String, String> test = this.createFromArgsTest();
        Map<String, String> expected = this.createFromArgsRef("a", "1");

        test.add("a", "1");
        assertEquals(expected, test);
    }

    @Test
    public final void testAdd02() {
        Map<String, String> test = this.createFromArgsTest("a", "1");
        Map<String, String> expected = this.createFromArgsRef("a", "1", "b",
                "2");

        test.add("b", "2");
        assertEquals(expected, test);
    }

    @Test
    public final void testRemove01() {
        Map<String, String> test = this.createFromArgsTest("a", "1");
        Map<String, String> expected = this.createFromArgsRef();

        test.remove("a");
        assertEquals(expected, test);
    }

    @Test
    public final void testRemove02() {
        Map<String, String> test = this.createFromArgsTest("a", "1", "b", "2");
        Map<String, String> expected = this.createFromArgsRef("b", "2");

        test.remove("a");
        assertEquals(expected, test);
    }

    @Test
    public final void testRemoveAny01() {
        Map<String, String> test = this.createFromArgsTest("a", "1");
        Map<String, String> expected = this.createFromArgsRef("a", "1");

        Map.Pair<String, String> n = test.removeAny();

        assertEquals(true, expected.hasKey(n.key()));
        expected.remove(n.key());
        assertEquals(expected, test);
    }

    @Test
    public final void testRemoveAny02() {
        Map<String, String> test = this.createFromArgsTest("a", "1", "b", "2");
        Map<String, String> expected = this.createFromArgsRef("a", "1", "b",
                "2");

        Map.Pair<String, String> n = test.removeAny();

        assertEquals(true, expected.hasKey(n.key()));
        expected.remove(n.key());
        assertEquals(expected, test);
    }

    @Test
    public final void testSize01() {
        Map<String, String> test = this.createFromArgsTest();
        int size = 0;

        assertEquals(test.size(), size);
    }

    @Test
    public final void testSize02() {
        Map<String, String> test = this.createFromArgsTest("a", "1");
        int size = 1;

        assertEquals(test.size(), size);
    }

    @Test
    public final void testSize03() {
        Map<String, String> test = this.createFromArgsTest("a", "1", "b", "2");
        int size = 2;

        assertEquals(test.size(), size);
    }

    @Test
    public final void testHasKey01() {
        Map<String, String> test = this.createFromArgsTest();

        assertEquals(false, test.hasKey(""));
    }

    @Test
    public final void testHasKey02() {
        Map<String, String> test = this.createFromArgsTest("a", "1");

        assertTrue(test.hasKey("a"));
    }

    @Test
    public final void testHasKey03() {
        Map<String, String> test = this.createFromArgsTest("a", "1", "b", "2");

        assertTrue(!test.hasKey("1"));
    }

    @Test
    public final void testHasKey04() {
        Map<String, String> test = this.createFromArgsTest("a", "1", "b", "2");

        assertTrue(!test.hasKey("c"));
    }

    @Test
    public final void testValue01() {
        Map<String, String> test = this.createFromArgsTest("a", "1");
        Map<String, String> expected = this.createFromArgsRef("a", "1");

        String value = test.value("a");
        assertEquals(value, expected.value("a"));
    }

    @Test
    public final void testValue02() {
        Map<String, String> test = this.createFromArgsTest("a", "1", "b", "2");
        Map<String, String> expected = this.createFromArgsRef("b", "2");
        String value = test.value("b");
        assertEquals(value, expected.value("b"));
    }

}