import java.util.Comparator;

import components.map.Map;
import components.map.Map1L;
import components.queue.Queue;
import components.queue.Queue1L;
import components.set.Set;
import components.set.Set1L;
import components.simplereader.SimpleReader;
import components.simplereader.SimpleReader1L;
import components.simplewriter.SimpleWriter;
import components.simplewriter.SimpleWriter1L;
import components.sortingmachine.SortingMachine;
import components.sortingmachine.SortingMachine1L;

/**
 * a Java program that counts word occurrences in a given input file and outputs
 * an HTML document with a table of the words and counts listed in alphabetical
 * order.
 *
 * @author Huiyan Ni
 */
public final class TagCloud {

    /**
     * Default constructor--private to prevent instantiation.
     */

    // compare key in map by using alphabetical order
    private static class alphaList
            implements Comparator<Map.Pair<String, Integer>> {
        @Override
        public int compare(Map.Pair<String, Integer> m1,
                Map.Pair<String, Integer> m2) {
            return m1.key().toLowerCase().compareTo(m2.key().toLowerCase());
        }

    }

    // compare value in map by using number decreasing order
    private static class numberList
            implements Comparator<Map.Pair<String, Integer>> {
        @Override
        public int compare(Map.Pair<String, Integer> m1,
                Map.Pair<String, Integer> m2) {
            return m2.value().compareTo(m1.value());
        }

    }

    // generate a map of words and corresponding counts and a queue of strings.

    private static void readInputFile(SimpleReader input,
            Map<String, Integer> wordsAndCount, Queue<String> wordlist) {

        // generate several separators which may appear in input file.
        Set<Character> separators = new Set1L<Character>();
        separators.add(' ');
        separators.add('\t');
        separators.add('\n');
        separators.add('\r');
        separators.add('[');
        separators.add(']');
        separators.add('(');
        separators.add(')');
        separators.add('!');
        separators.add(';');
        separators.add(':');
        separators.add(',');
        separators.add('?');
        separators.add('.');
        separators.add('-');
        separators.add('~');
        separators.add('0');
        separators.add('1');
        separators.add('2');
        separators.add('3');
        separators.add('4');
        separators.add('5');
        separators.add('6');
        separators.add('7');
        separators.add('8');
        separators.add('9');
        separators.add('*');
        separators.add('_');
        separators.add('\'');

        // create a map and generate it by reading input file
        int countnumber = 0;
        String line = " ";
        String word = " ";

        while (!input.atEOS()) {
            countnumber = 0;
            line = input.nextLine();
            while (!line.isEmpty()) {
                int pos = 0;

                word = nextWordOrSep(line, pos, separators);
                word = word.toLowerCase();
                line = line.substring(word.length(), line.length());

                if (!separators.contains(word.charAt(0))) {
                    //if the word already appeared in previous
                    if (wordsAndCount.hasKey(word)) {
                        countnumber = wordsAndCount.value(word);
                        wordsAndCount.remove(word);
                        countnumber++;
                        wordsAndCount.add(word, countnumber);
                    } else {
                        // if the word is new to list
                        countnumber = 0;
                        wordlist.enqueue(word);
                        countnumber++;
                        wordsAndCount.add(word, countnumber);
                    }
                }

            }
        }

    }

    // separate the next word or separator
    private static String nextWordOrSep(String text, int pos,
            Set<Character> separators) {

        StringBuilder cha = new StringBuilder();
        // if the word is new
        if (separators.contains(text.charAt(pos))) {
            for (int i = pos; i < text.length()
                    && separators.contains(text.charAt(i)); i++) {
                cha.append(text.charAt(i));

            }
        } else {
            // if the word already appeared in previous
            for (int i = pos; i < text.length()
                    && !separators.contains(text.charAt(i)); i++) {
                cha.append(text.charAt(i));

            }
        }
        String result = cha.toString();
        return result;
    }

    // generate the tag cloud show in output file
    private static void generateOutput(String inputname, String outputname,
            Queue<String> wordlist, Map<String, Integer> wordAndCount,
            SimpleWriter output, int highest,
            SortingMachine<Map.Pair<String, Integer>> sort2, int number) {

        // generate the title and header
        output.println("<html>");
        output.println("<head>");
        output.println("<title> Top " + number + " words in " + outputname
                + "</title>");
        output.println(
                "<link href=\"http://web.cse.ohio-state.edu/software/2231/web-sw2/assignments/projects/tag-cloud-generator/data/tagcloud.css\" rel=\"stylesheet\" type=\"text/css\">");
        output.println("</head>");
        output.println("<body>");
        output.println(
                "<h1>Top " + number + " words in " + inputname + "</h1>");
        output.println("<hr>");
        output.println("<div class = \"cdiv\">");
        output.println("<p class = \"cbox\">");

        //generate the tag cloud
        double thirtySeven = 37.0;
        int eleven = 11;
        for (Map.Pair<String, Integer> x : sort2) {
            int font = x.value();
            int fontSize = (int) ((thirtySeven / (highest - 1)) * (font - 1)
                    + eleven);
            output.println("<span style=\"cursor:default\" class=\"f" + fontSize
                    + "\"title=\"count: " + font + "\">" + x.key() + "</span>");
        }

        //generate the footer
        output.println("</p>");
        output.println("</div>");
        output.println("</body>");
        output.println("</html>");

    }

    /**
     * Main method.
     *
     * @param args
     *            the command line arguments; unused here
     */
    public static void main(String[] args) {

        SimpleReader in = new SimpleReader1L();
        SimpleWriter out = new SimpleWriter1L();

        //ask for the name of the input file and output file
        out.println("Enter the name of the input file: ");
        String inputfile = in.nextLine();

        out.println("Enter the name of the output file: ");
        String outputfile = in.nextLine();

        //ask for the number of words
        out.println("Enter the number of words: ");
        int number = Integer.parseInt(in.nextLine());

        SimpleReader input = new SimpleReader1L(inputfile);

        Map<String, Integer> wordAndCount = new Map1L<String, Integer>();
        Queue<String> wordlist = new Queue1L<String>();

        //generate the output tag cloud
        readInputFile(input, wordAndCount, wordlist);
        SimpleWriter output = new SimpleWriter1L(outputfile);

        // create relative SortingMachine to sort the value and map in map
        Comparator<Map.Pair<String, Integer>> order1 = new numberList();
        Comparator<Map.Pair<String, Integer>> order2 = new alphaList();

        SortingMachine<Map.Pair<String, Integer>> sort1 = new SortingMachine1L<>(
                order1);
        SortingMachine<Map.Pair<String, Integer>> sort2 = new SortingMachine1L<>(
                order2);

        for (Map.Pair<String, Integer> x : wordAndCount) {
            sort1.add(x);
        }
        sort1.changeToExtractionMode();

        Map.Pair<String, Integer> start = sort1.removeFirst();
        sort2.add(start);

        int size = wordAndCount.size();
        for (int i = 0; i < number && i < size; i++) {
            sort2.add(sort1.removeFirst());
        }
        sort2.changeToExtractionMode();

        int highest = start.value();

        generateOutput(inputfile, outputfile, wordlist, wordAndCount, output,
                highest, sort2, number);

        in.close();
        input.close();
        out.close();
        output.close();

    }

}
