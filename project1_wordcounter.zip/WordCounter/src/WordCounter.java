import components.map.Map;
import components.map.Map1L;
import components.queue.Queue;
import components.queue.Queue1L;
import components.set.Set;
import components.set.Set1L;
import components.simplereader.SimpleReader;
import components.simplereader.SimpleReader1L;
import components.simplewriter.SimpleWriter;
import components.simplewriter.SimpleWriter1L;

import java.util.Comparator;

/**
 * Count the frequency of different words in a document and list them in a HTML page
 *
 * @author ZiyiWang
 *
 */
public class WordCounter {
    /**
     * Private no-argument constructor to prevent instantiation of this utility
     * class.
     */
    private WordCounter() {
    }

    /**
     * read the inputFile and store the document in a String
     *
     * @param inputFile
     *            the file path which will be read
     *
     * @ensures reader.is_closed
     *
     * @return the content in the given inputFile
     *
     */
    public static String readFile(String inputFile) {
        assert inputFile != null : "Violation of: inputFile is not null";

        SimpleReader reader = new SimpleReader1L(inputFile);
        String doc = "";
        while (!reader.atEOS()) {
            String next = reader.nextLine();
            doc += " " + next;
        }
        reader.close();
        return doc;
    }

    /**
     * Compare {@code String}s in lexicographic order.
     */
    private static class StringLT implements Comparator<String> {
        @Override
        public int compare(String o1, String o2) {
            return o1.compareTo(o2);
        }
    }

    /**
     * Divide and count the words according to doc, store them in freqMap, 
     * and sort different words in WordQueue lexicographically
     *
     * @param doc
     *            the content in the inputFile
     * @param freqMap
     *            stores different word and its frequency
     * @param wordQueue
     *            a queue stores all the terms which has been sorted in
     *            lexicographical order
     * @updates freqMap
     * @updates wordQueue
     *
     */
    private static void countWord(String doc, Map<String, Integer> freqMap, Queue<String> wordQueue) {
        assert doc != null : "Violation of: doc is not null";
        assert freqMap != null : "Violation of: freqMap not null";
        assert wordQueue != null : "Violation of: wordQueue is not null";
        Set<Character> separators = new Set1L<>();
        separators.add(' ');
        separators.add('-');
        separators.add(',');
        separators.add('.');
        int i = 0;
        while (i < doc.length()) {
            // run if character at i is in separator set
            while (i < doc.length() && separators.contains(doc.charAt(i)))
                i++;
            int start = i;
            while (i < doc.length() && !separators.contains(doc.charAt(i)))
                i++;
            int end = i;
            String word = doc.substring(start, end).toLowerCase();
            if(!word.equals("")){
                if(!freqMap.hasKey(word)){
                    wordQueue.enqueue(word);
                    freqMap.add(word,1);
                }else{
                    int freq = freqMap.value(word);
                    freqMap.replaceValue(word,freq+1);
                }
            }else
                break;
        }
        Comparator<String> order = new StringLT();
        wordQueue.sort(order);
    }
    /**
     * Generate an index HTML page into directory "data".
     * According to the words in wordQueue one by one to 
     * freqMap to query the number of times it appears in the document and generate HTML.
     * 
     * @param inputFile
     *            the file path which will be read
     * @param freqMap
     *            stores different word and its frequency
     * @param wordQueue
     *            a queue stores all the terms which has been sorted in
     *            lexicographical order
     * @clears {@code freMap}, {@code wordQueue}
     * 
     */


    public static void generatePage(String inputFile,String outputFolder, Map<String, Integer> freqMap, Queue<String> wordQueue){
        assert inputFile != null : "Violation of : inputFile is not null";
        assert freqMap != null : "Violation of : freqMap is not null";
        assert wordQueue != null : "Violation of: termQueue is not null";

        int idx_1 = inputFile.lastIndexOf('/');
        int idx_2 = inputFile.lastIndexOf('.');
        SimpleWriter writer = new SimpleWriter1L(outputFolder + "/" + inputFile.substring(idx_1,idx_2) + ".html");
        // print header
        writer.println("<html>");
        writer.println("<head>");
        writer.println("<title>Words Counted in "+inputFile+"</title>");
        writer.println("</head>");
        writer.println("<body>");
        writer.println("<h2>Words Counted in "+inputFile+"</h2>");
        writer.println("<hr />");
        writer.println("<table border=\"1\">");
        writer.println("<tr>\n" +
                "<th>Words</th>\n" +
                "<th>Counts</th>\n" +
                "</tr>");
        for(String word : wordQueue){
            writer.println("<tr>\n" +
                    "<td>"+word+"</td>\n" +
                    "<td>"+freqMap.value(word)+"</td>\n" +
                    "</tr>");
        }
        writer.println("</table>\n" +
                "</body>\n" +
                "</html>");
    }
    
    public static void main(String[] args) {
        SimpleReader in = new SimpleReader1L();
        SimpleWriter out = new SimpleWriter1L();
        out.println("Enter the path of input file: ");
        String inputFile = in.nextLine();
        out.println("Enter the path of output folder: ");
        String outputFolder = in.nextLine();
        Map<String, Integer> freqMap = new Map1L<String, Integer>();
        Queue<String> wordQueue = new Queue1L<>();
        String doc = readFile(inputFile);
        countWord(doc,freqMap,wordQueue);
        generatePage(inputFile,outputFolder,freqMap,wordQueue);
        in.close();
        out.close();
    }
}
