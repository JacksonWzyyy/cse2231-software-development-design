import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

import components.set.Set;

/**
 * JUnit test fixture for {@code Set<String>}'s constructor and kernel methods.
 *
 * @author Ziyi Wang, Huiyan Ni
 *
 */
public abstract class SetTest {

    /**
     * Invokes the appropriate {@code Set} constructor for the implementation
     * under test and returns the result.
     *
     * @return the new set
     * @ensures constructorTest = {}
     */
    protected abstract Set<String> constructorTest();

    /**
     * Invokes the appropriate {@code Set} constructor for the reference
     * implementation and returns the result.
     *
     * @return the new set
     * @ensures constructorRef = {}
     */
    protected abstract Set<String> constructorRef();

    /**
     * Creates and returns a {@code Set<String>} of the implementation under
     * test type with the given entries.
     *
     * @param args
     *            the entries for the set
     * @return the constructed set
     * @requires [every entry in args is unique]
     * @ensures createFromArgsTest = [entries in args]
     */
    private Set<String> createFromArgsTest(String... args) {
        Set<String> set = this.constructorTest();
        for (String s : args) {
            assert !set.contains(
                    s) : "Violation of: every entry in args is unique";
            set.add(s);
        }
        return set;
    }

    /**
     * Creates and returns a {@code Set<String>} of the reference implementation
     * type with the given entries.
     *
     * @param args
     *            the entries for the set
     * @return the constructed set
     * @requires [every entry in args is unique]
     * @ensures createFromArgsRef = [entries in args]
     */
    private Set<String> createFromArgsRef(String... args) {
        Set<String> set = this.constructorRef();
        for (String s : args) {
            assert !set.contains(
                    s) : "Violation of: every entry in args is unique";
            set.add(s);
        }
        return set;
    }

    // TODO - add test cases for constructor, add, remove, removeAny, contains, and size

    /*
     * Test cases for constructors
     */

    @Test
    public final void testConstructor() {
        Set<String> test = this.createFromArgsTest();
        Set<String> expected = this.createFromArgsRef();
        /*
         * Assert that values of variables match expectations
         */
        assertEquals(expected, test);
    }

    /*
     * Test cases for add
     */

    @Test
    public final void testAdd01() {
        Set<String> test = this.createFromArgsTest();
        Set<String> expected = this.createFromArgsRef("apple");
        test.add("apple");
        assertEquals(expected, test);
    }

    @Test
    public final void testAdd02() {
        Set<String> test = this.createFromArgsTest("apple", "banana");
        Set<String> expected = this.createFromArgsRef("apple", "banana", "eat");
        test.add("eat");
        assertEquals(expected, test);
    }

    @Test
    public final void testAdd03() {

        Set<String> test = this.createFromArgsTest("apple", "banana", "eat");
        Set<String> expected = this.createFromArgsRef("apple", "banana", "eat",
                "good");
        test.add("good");

        assertEquals(expected, test);
    }

    /*
     * Test cases for remove
     */

    @Test
    public final void testRemove01() {
        Set<String> test = this.createFromArgsTest("good");
        Set<String> expected = this.createFromArgsRef();
        String E = test.remove("good");
        String R = "good";
        assertEquals(test, expected);
        assertEquals(E, R);
    }

    /**
     * Test remove one leaving one.
     */
    @Test
    public final void testRemove02() {
        Set<String> test = this.createFromArgsTest("apple", "banana");
        Set<String> expected = this.createFromArgsRef("apple");

        String E = test.remove("banana");
        String R = "banana";
        assertEquals(test, expected);
        assertEquals(E, R);
    }

    @Test
    public final void testRemove03() {
        Set<String> test = this.createFromArgsTest("apple", "banana", "eat",
                "good");
        Set<String> expected = this.createFromArgsRef("apple", "banana",
                "good");

        String E = test.remove("eat");
        String R = "eat";
        assertEquals(test, expected);
        assertEquals(E, R);
    }

    /*
     * Test cases for removeAny
     */

    @Test
    public final void testRemoveAny01() {
        Set<String> test = this.createFromArgsTest("apple");
        Set<String> expected = this.createFromArgsRef("apple");

        String E = test.removeAny();
        assertEquals(true, expected.contains(E));
        expected.remove(E);
        assertEquals(expected, test);
    }

    @Test
    public final void testRemoveAny02() {
        Set<String> test = this.createFromArgsTest("apple", "eat");
        Set<String> expected = this.createFromArgsRef("apple", "eat");

        String E = test.removeAny();
        assertEquals(true, expected.contains(E));
        expected.remove(E);
        assertEquals(expected, test);
    }

    @Test
    public final void testRemoveAny03() {
        Set<String> test = this.createFromArgsTest("apple", "banana", "eat",
                "good");
        Set<String> expected = this.createFromArgsRef("apple", "banana", "eat",
                "good");

        String E = test.removeAny();
        assertEquals(true, expected.contains(E));
        expected.remove(E);
        assertEquals(expected, test);
    }
    /*
     * Test cases for contains
     */

    @Test
    public final void testContains01() {
        Set<String> test = this.createFromArgsTest("apple");
        Set<String> expected = this.createFromArgsRef("apple");
        boolean contains = test.contains("apple");
        assertTrue(contains);
        assertEquals(expected, test);
    }

    @Test
    public final void testContains02() {
        Set<String> test = this.createFromArgsTest("apple", "banana", "eat");
        Set<String> expected = this.createFromArgsRef("apple", "banana", "eat");
        boolean contains = test.contains("apple");
        assertTrue(contains);
        assertEquals(expected, test);
    }

    @Test
    public final void testContains03() {
        Set<String> test = this.createFromArgsTest("apple", "banana", "eat");
        Set<String> expected = this.createFromArgsRef("apple", "banana", "eat");
        boolean contains = test.contains("good");
        assertTrue(!contains);
        assertEquals(expected, test);
    }

    /*
     * Test cases for size
     */

    @Test
    public final void testSize01() {
        Set<String> test = this.createFromArgsTest();
        Set<String> expected = this.createFromArgsRef();
        assertEquals(expected, test);
        assertEquals(test.size(), 0);
    }

    @Test
    public final void testSize02() {
        Set<String> test = this.createFromArgsTest("apple");
        Set<String> expected = this.createFromArgsRef("apple");
        assertEquals(test.size(), 1);
        assertEquals(expected, test);
    }

    @Test
    public final void testSize03() {
        Set<String> test = this.createFromArgsTest("apple", "eat");
        Set<String> expected = this.createFromArgsRef("apple", "eat");
        assertEquals(test.size(), 2);
        assertEquals(expected, test);
    }

    @Test
    public final void testSize04() {
        Set<String> test = this.createFromArgsTest("apple", "banana", "eat");
        Set<String> expected = this.createFromArgsRef("apple", "banana", "eat");
        assertEquals(test.size(), 3);
        assertEquals(expected, test);

    }
}
