import static org.junit.Assert.assertEquals;

import org.junit.Test;

import components.naturalnumber.NaturalNumber;
import components.naturalnumber.NaturalNumber1L;

/**
 * JUnit test fixture for {@code NaturalNumber}'s constructors and kernel
 * methods.
 *
 * @author Huiyan Ni
 *
 */
public abstract class NaturalNumberTest {

    /**
     * Invokes the appropriate {@code NaturalNumber} constructor for the
     * implementation under test and returns the result.
     *
     * @return the new number
     * @ensures constructorTest = 0
     */
    protected abstract NaturalNumber constructorTest();

    /**
     * Invokes the appropriate {@code NaturalNumber} constructor for the
     * implementation under test and returns the result.
     *
     * @param i
     *            {@code int} to initialize from
     * @return the new number
     * @requires i >= 0
     * @ensures constructorTest = i
     */
    protected abstract NaturalNumber constructorTest(int i);

    /**
     * Invokes the appropriate {@code NaturalNumber} constructor for the
     * implementation under test and returns the result.
     *
     * @param s
     *            {@code String} to initialize from
     * @return the new number
     * @requires there exists n: NATURAL (s = TO_STRING(n))
     * @ensures s = TO_STRING(constructorTest)
     */
    protected abstract NaturalNumber constructorTest(String s);

    /**
     * Invokes the appropriate {@code NaturalNumber} constructor for the
     * implementation under test and returns the result.
     *
     * @param n
     *            {@code NaturalNumber} to initialize from
     * @return the new number
     * @ensures constructorTest = n
     */
    protected abstract NaturalNumber constructorTest(NaturalNumber n);

    /**
     * Invokes the appropriate {@code NaturalNumber} constructor for the
     * reference implementation and returns the result.
     *
     * @return the new number
     * @ensures constructorRef = 0
     */
    protected abstract NaturalNumber constructorRef();

    /**
     * Invokes the appropriate {@code NaturalNumber} constructor for the
     * reference implementation and returns the result.
     *
     * @param i
     *            {@code int} to initialize from
     * @return the new number
     * @requires i >= 0
     * @ensures constructorRef = i
     */
    protected abstract NaturalNumber constructorRef(int i);

    /**
     * Invokes the appropriate {@code NaturalNumber} constructor for the
     * reference implementation and returns the result.
     *
     * @param s
     *            {@code String} to initialize from
     * @return the new number
     * @requires there exists n: NATURAL (s = TO_STRING(n))
     * @ensures s = TO_STRING(constructorRef)
     */
    protected abstract NaturalNumber constructorRef(String s);

    /**
     * Invokes the appropriate {@code NaturalNumber} constructor for the
     * reference implementation and returns the result.
     *
     * @param n
     *            {@code NaturalNumber} to initialize from
     * @return the new number
     * @ensures constructorRef = n
     */
    protected abstract NaturalNumber constructorRef(NaturalNumber n);

    // TODO - add test cases for four constructors, multiplyBy10, divideBy10, isZero

    /**
     * Test case for No Argument constructor
     */

    @Test
    public final void testNoArugumentConstructor() {
        NaturalNumber s = this.constructorTest();
        NaturalNumber sExpected = this.constructorRef();

        assertEquals(s, sExpected);
    }

    /**
     * Test case for integer constructor with 0
     */
    @Test
    public final void testIntConstructor1() {

        int temp = 0;
        NaturalNumber s = this.constructorTest(temp);
        NaturalNumber sExpected = this.constructorRef(temp);

        assertEquals(s, sExpected);
    }

    /**
     * Test case for integer constructor with 5
     */
    @Test
    public final void testIntConstructor2() {

        int temp = 5;
        NaturalNumber s = this.constructorTest(temp);
        NaturalNumber sExpected = this.constructorRef(temp);

        assertEquals(s, sExpected);
    }

    /**
     * Test case for integer constructor with 9999
     */
    @Test
    public final void testIntConstructor3() {

        int temp = 9999;
        NaturalNumber s = this.constructorTest(temp);
        NaturalNumber sExpected = this.constructorRef(temp);

        assertEquals(s, sExpected);
    }

    /**
     * Test case for string constructor with 0
     */
    @Test
    public final void testStrConstructor1() {

        String temp = "0";
        NaturalNumber s = this.constructorTest(temp);
        NaturalNumber sExpected = this.constructorRef(temp);

        assertEquals(s, sExpected);
    }

    /**
     * Test case for string constructor with 5
     */
    @Test
    public final void testStrConstructor2() {

        String temp = "5";
        NaturalNumber s = this.constructorTest(temp);
        NaturalNumber sExpected = this.constructorRef(temp);

        assertEquals(s, sExpected);
    }

    /**
     * Test case for string constructor with 9999
     */
    @Test
    public final void testStrConstructor3() {

        String temp = "9999";
        NaturalNumber s = this.constructorTest(temp);
        NaturalNumber sExpected = this.constructorRef(temp);

        assertEquals(s, sExpected);
    }

    /**
     * Test case for NaturalNumber constructor with 0
     */
    @Test
    public final void testNNConstructor1() {

        NaturalNumber temp = new NaturalNumber3(0);
        NaturalNumber s = this.constructorTest(temp);
        NaturalNumber sExpected = this.constructorRef(temp);

        assertEquals(s, sExpected);
    }

    /**
     * Test case for NaturalNumber constructor with 5
     */
    @Test
    public final void testNNConstructor2() {

        NaturalNumber temp = new NaturalNumber3(5);
        NaturalNumber temp1 = new NaturalNumber1L(5);

        NaturalNumber s = this.constructorTest(temp);
        NaturalNumber sExpected = this.constructorRef(temp1);

        assertEquals(s, sExpected);
    }

    /**
     * Test case for NaturalNumber constructor with 9999
     */
    @Test
    public final void testNNConstructor3() {

        NaturalNumber temp = new NaturalNumber3(9999);
        NaturalNumber temp1 = new NaturalNumber1L(9999);
        NaturalNumber s = this.constructorTest(temp);
        NaturalNumber sExpected = this.constructorRef(temp1);

        assertEquals(s, sExpected);
    }

    /**
     * Test case for multiplyBy10 with 0 and 3
     */
    @Test
    public final void test1MultiplyBy10() {

        NaturalNumber s = this.constructorTest(0);
        NaturalNumber sExpected = this.constructorRef(3);

        s.multiplyBy10(3);

        assertEquals(s, sExpected);
    }

    /**
     * Test case for multiplyBy10 with 0 and 0
     */
    @Test
    public final void test2MultiplyBy10() {

        NaturalNumber s = this.constructorTest(0);
        NaturalNumber sExpected = this.constructorRef(0);

        s.multiplyBy10(0);

        assertEquals(s, sExpected);
    }

    /**
     * Test case for multiplyBy10 with 76 and 0
     */
    @Test
    public final void test3MultiplyBy10() {

        NaturalNumber s = this.constructorTest(76);
        NaturalNumber sExpected = this.constructorRef(760);

        s.multiplyBy10(0);

        assertEquals(s, sExpected);
    }

    /**
     * Test case for multiplyBy10 with 999 and 8
     */
    @Test
    public final void test4MultiplyBy10() {

        NaturalNumber s = this.constructorTest(999);
        NaturalNumber sExpected = this.constructorRef(9998);

        s.multiplyBy10(8);

        assertEquals(s, sExpected);
    }

    /**
     * Test case for divideBy10 with 0
     */
    @Test
    public final void test1DivideBy10() {

        NaturalNumber s = this.constructorTest(0);
        NaturalNumber sExpected = this.constructorRef(0);

        int n = s.divideBy10();

        assertEquals(s, sExpected);
        assertEquals(n, 0);
    }

    /**
     * Test case for divideBy10 with 6
     */
    @Test
    public final void test2DivideBy10() {

        NaturalNumber s = this.constructorTest(6);
        NaturalNumber sExpected = this.constructorRef(0);

        int n = s.divideBy10();

        assertEquals(s, sExpected);
        assertEquals(n, 6);
    }

    /**
     * Test case for divideBy10 with 886
     */
    @Test
    public final void test3DivideBy10() {

        NaturalNumber s = this.constructorTest(886);
        NaturalNumber sExpected = this.constructorRef(88);

        int n = s.divideBy10();

        assertEquals(s, sExpected);
        assertEquals(n, 6);
    }

    /**
     * Test case for divideBy10 with 9990
     */
    @Test
    public final void test4DivideBy10() {

        NaturalNumber s = this.constructorTest(9990);
        NaturalNumber sExpected = this.constructorRef(999);

        int n = s.divideBy10();

        assertEquals(s, sExpected);
        assertEquals(n, 0);
    }

    /**
     * Test case for isZero with 886
     */
    @Test
    public final void test1IsZero() {

        NaturalNumber n = this.constructorTest(886);

        boolean s = n.isZero();
        boolean sExpected = false;

        assertEquals(s, sExpected);

    }

    /**
     * Test case for isZero with 0
     */
    @Test
    public final void test2IsZero() {

        NaturalNumber n = this.constructorTest(0);

        boolean s = n.isZero();
        boolean sExpected = true;

        assertEquals(s, sExpected);

    }

    /**
     * Test case for isZero with 1006
     */
    @Test
    public final void test3IsZero() {

        NaturalNumber n = this.constructorTest(1003);

        boolean s = n.isZero();
        boolean sExpected = false;

        assertEquals(s, sExpected);

    }

}
